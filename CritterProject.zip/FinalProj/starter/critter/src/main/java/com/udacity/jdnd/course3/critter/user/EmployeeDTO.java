package com.udacity.jdnd.course3.critter.user;

import java.util.Set;
import java.time.DayOfWeek;

public class EmployeeDTO {

    private Set<DayOfWeek> daysAvailable;
    private Set<EmployeeSkill> skills;
    private String name;
    private long id;

    public Set<DayOfWeek> getDaysAvailable() {
        return daysAvailable;
    }

    public void setDaysAvailable(Set<DayOfWeek> daysAvailable) {
        this.daysAvailable = daysAvailable;
    }

    public Set<EmployeeSkill> getSkills() {
        return skills;
    }

    public void setSkills(Set<EmployeeSkill> skills) {
        this.skills = skills;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
