package com.udacity.jdnd.course3.critter.user;

import com.udacity.jdnd.course3.critter.pet.Pet;
import com.udacity.jdnd.course3.critter.pet.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;
import java.util.Collections;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserService {

    private final CustomerRepository customerRepository;
    private final EmployeeRepository employeeRepository;
    private final PetRepository petRepository;

    @Autowired
    public UserService(CustomerRepository customerRepository,
                       EmployeeRepository employeeRepository,
                       PetRepository petRepository) {
        this.customerRepository = customerRepository;
        this.employeeRepository = employeeRepository;
        this.petRepository = petRepository;
    }

    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerById(Long customerId) {
        return customerRepository.findById(customerId).orElse(null);
    }

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee getEmployeeById(Long employeeId) {
        return employeeRepository.findById(employeeId).orElse(null);
    }

    public void setAvailability(Set<DayOfWeek> availability, Long employeeId) {
        employeeRepository.findById(employeeId).ifPresent(employee -> {
            employee.setDaysAvailable(availability);
            employeeRepository.save(employee);
        });
    }

    public List<Employee> findEmployeesForService(DayOfWeek day,
                                                  Set<EmployeeSkill> requiredSkills) {

        if (requiredSkills == null || requiredSkills.isEmpty()) {
            return Collections.emptyList();
        }

        return employeeRepository.findAllByDaysAvailable(day)
                .stream()
                .filter(e -> e.getSkills() != null)
                .filter(e -> e.getSkills().containsAll(requiredSkills))
                .collect(Collectors.toList());
    }

    public Customer getOwnerByPet(Long petId) {
        return petRepository.findById(petId)
                .map(Pet::getCustomer)
                .orElse(null);
    }
}
