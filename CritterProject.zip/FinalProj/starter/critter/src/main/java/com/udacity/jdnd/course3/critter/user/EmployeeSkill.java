package com.udacity.jdnd.course3.critter.user;

public enum EmployeeSkill {
    WALKING,
    FEEDING,
    PETTING,
    MEDICATING,
    SHAVING
}
