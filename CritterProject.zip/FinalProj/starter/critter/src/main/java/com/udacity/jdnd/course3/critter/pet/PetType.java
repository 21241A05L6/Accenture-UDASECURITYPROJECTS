package com.udacity.jdnd.course3.critter.pet;

public enum PetType {
    DOG,
    CAT,
    BIRD,
    FISH,
    LIZARD,
    SNAKE,
    OTHER
}
