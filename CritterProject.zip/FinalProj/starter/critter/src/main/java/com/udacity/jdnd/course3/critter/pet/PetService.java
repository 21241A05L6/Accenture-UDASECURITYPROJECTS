package com.udacity.jdnd.course3.critter.pet;

import com.udacity.jdnd.course3.critter.user.Customer;
import com.udacity.jdnd.course3.critter.user.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PetService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PetRepository petRepository;

    public Pet getPet(Long petId) {
        return petRepository.findById(petId).orElse(null);
    }

    public List<Pet> getPetsByOwner(Long ownerId) {
        return petRepository.findAllByCustomerId(ownerId);
    }

    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    public Pet savePet(Pet pet, Long ownerId) {
        Customer customer = customerRepository.findById(ownerId).orElse(null);

        if (customer != null) {
            pet.setCustomer(customer);
            Pet savedPet = petRepository.save(pet);
            customer.addPet(savedPet);
            customerRepository.save(customer);
            return savedPet;
        }

        return pet;
    }
}
