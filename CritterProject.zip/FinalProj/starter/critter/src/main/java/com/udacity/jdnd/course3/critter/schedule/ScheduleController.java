package com.udacity.jdnd.course3.critter.schedule;

import com.udacity.jdnd.course3.critter.pet.Pet;
import com.udacity.jdnd.course3.critter.user.Employee;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/schedule")
public class ScheduleController {

    private final ScheduleService service;

    public ScheduleController(ScheduleService service) {
        this.service = service;
    }

    @PostMapping
    public ScheduleDTO createSchedule(@RequestBody ScheduleDTO input) {
        Schedule schedule = new Schedule();
        schedule.setDate(input.getDate());
        schedule.setActivities(input.getActivities());

        Schedule saved = service.createSchedule(
                schedule,
                input.getEmployeeIds(),
                input.getPetIds()
        );

        return buildDTO(saved);
    }

    @GetMapping
    public List<ScheduleDTO> getAllSchedules() {
        List<ScheduleDTO> result = new ArrayList<>();

        for (Schedule schedule : service.getAllSchedules()) {
            result.add(buildDTO(schedule));
        }

        return result;
    }

    @GetMapping("/pet/{petId}")
    public List<ScheduleDTO> getScheduleForPet(@PathVariable long petId) {
        List<ScheduleDTO> output = new ArrayList<>();

        for (Schedule schedule : service.getScheduleForPet(petId)) {
            output.add(buildDTO(schedule));
        }

        return output;
    }

    @GetMapping("/employee/{employeeId}")
    public List<ScheduleDTO> getScheduleForEmployee(@PathVariable long employeeId) {
        List<ScheduleDTO> output = new ArrayList<>();

        for (Schedule schedule : service.getScheduleForEmployee(employeeId)) {
            output.add(buildDTO(schedule));
        }

        return output;
    }

    @GetMapping("/customer/{customerId}")
    public List<ScheduleDTO> getScheduleForCustomer(@PathVariable long customerId) {
        List<ScheduleDTO> result = new ArrayList<>();

        for (Schedule schedule : service.getScheduleForCustomer(customerId)) {
            result.add(buildDTO(schedule));
        }

        return result;
    }

    private ScheduleDTO buildDTO(Schedule schedule) {
        ScheduleDTO dto = new ScheduleDTO();
        dto.setId(schedule.getId());
        dto.setDate(schedule.getDate());
        dto.setActivities(schedule.getActivities());

        if (schedule.getEmployees() != null) {
            List<Long> employeeIds = new ArrayList<>();
            for (Employee e : schedule.getEmployees()) {
                employeeIds.add(e.getId());
            }
            dto.setEmployeeIds(employeeIds);
        }

        if (schedule.getPets() != null) {
            List<Long> petIds = new ArrayList<>();
            for (Pet p : schedule.getPets()) {
                petIds.add(p.getId());
            }
            dto.setPetIds(petIds);
        }

        return dto;
    }
}
