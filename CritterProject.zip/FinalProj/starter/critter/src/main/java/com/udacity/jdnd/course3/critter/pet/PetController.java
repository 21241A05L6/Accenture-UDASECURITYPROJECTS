package com.udacity.jdnd.course3.critter.pet;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.ArrayList;

@RestController
@RequestMapping("/pet")
public class PetController {

    private final PetService service;

    public PetController(PetService service) {
        this.service = service;
    }

    @PostMapping
    public PetDTO savePet(@RequestBody PetDTO input) {
        Pet pet = new Pet();
        pet.setName(input.getName());
        pet.setType(input.getType());
        pet.setBirthDate(input.getBirthDate());
        pet.setNotes(input.getNotes());

        Pet stored = service.savePet(pet, input.getOwnerId());

        PetDTO response = new PetDTO();
        response.setId(stored.getId());
        response.setName(stored.getName());
        response.setType(stored.getType());
        response.setBirthDate(stored.getBirthDate());
        response.setNotes(stored.getNotes());

        if (stored.getCustomer() != null) {
            response.setOwnerId(stored.getCustomer().getId());
        }

        return response;
    }

    @GetMapping("/{id}")
    public PetDTO getPet(@PathVariable long id) {
        Pet pet = service.getPet(id);

        PetDTO dto = new PetDTO();
        dto.setId(pet.getId());
        dto.setName(pet.getName());
        dto.setType(pet.getType());
        dto.setBirthDate(pet.getBirthDate());
        dto.setNotes(pet.getNotes());

        if (pet.getCustomer() != null) {
            dto.setOwnerId(pet.getCustomer().getId());
        }

        return dto;
    }

    @GetMapping
    public List<PetDTO> getPets() {
        List<PetDTO> result = new ArrayList<>();

        for (Pet pet : service.getAllPets()) {
            PetDTO dto = new PetDTO();
            dto.setId(pet.getId());
            dto.setName(pet.getName());
            dto.setType(pet.getType());
            dto.setBirthDate(pet.getBirthDate());
            dto.setNotes(pet.getNotes());

            if (pet.getCustomer() != null) {
                dto.setOwnerId(pet.getCustomer().getId());
            }

            result.add(dto);
        }

        return result;
    }

    @GetMapping("/owner/{ownerId}")
    public List<PetDTO> getPetsByOwner(@PathVariable long ownerId) {
        List<PetDTO> output = new ArrayList<>();

        for (Pet pet : service.getPetsByOwner(ownerId)) {
            PetDTO dto = new PetDTO();
            dto.setId(pet.getId());
            dto.setName(pet.getName());
            dto.setType(pet.getType());
            dto.setBirthDate(pet.getBirthDate());
            dto.setNotes(pet.getNotes());

            if (pet.getCustomer() != null) {
                dto.setOwnerId(pet.getCustomer().getId());
            }

            output.add(dto);
        }

        return output;
    }
}
