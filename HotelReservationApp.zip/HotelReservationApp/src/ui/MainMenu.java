package ui;
import api.HotelResource;
import model.IRoom;
import model.Reservation;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;
public class MainMenu
{
    private static final HotelResource hotelResource = HotelResource.getInstance();
    private static final Scanner scanner = new Scanner(System.in);
    private static final String DATE_PATTERN = "MM/dd/yyyy";
    public static void showMainMenu() {
        String userInput = "";
        do
        {
            printMainMenu();
            userInput = scanner.nextLine();
            switch (userInput) {
                case "1":
                    findAndReserveRoom();
                    break;
                case "2":
                    seeMyReservations();
                    break;
                case "3":
                    createAccount();
                    break;
                case "4":
                    AdminMenu.showAdminMenu();
                    break;
                case "5":
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Please enter a number between 1 and 5.\n");
            }
        } while (!"5".equals(userInput));
    }
    private static void printMainMenu() {
        System.out.println("\nWelcome to the Hotel Reservation Application");
        System.out.println("--------------------------------------------");
        System.out.println("1. Find and reserve a room");
        System.out.println("2. See my reservations");
        System.out.println("3. Create an account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        System.out.println("--------------------------------------------");
        System.out.print("Please select a number for the menu option: ");
    }
    private static void createAccount()
    {
        System.out.print("Enter email (format: name@domain.com): ");
        String email = scanner.nextLine();
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        try
        {
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
        }
        catch (IllegalArgumentException e)
        {
            System.out.println("Error creating account: " + e.getMessage());
        }
    }
    private static void seeMyReservations()
    {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        Collection<Reservation> reservations = hotelResource.getCustomersReservations(email);
        if (reservations == null || reservations.isEmpty())
        {
            System.out.println("No reservations found for this email.");
        }
        else
        {
            for (Reservation reservation : reservations)
            {
                System.out.println(reservation);
            }
        }
    }
    private static void findAndReserveRoom()
    {
        try
        {
            Date checkIn;
            while (true)
            {
                try
                {
                    checkIn = readDate("Enter Check-In Date (MM/dd/yyyy): ");
                }
                catch (ParseException pe)
                {
                    System.out.println("Invalid date format. Please use MM/dd/yyyy.");
                    continue;
                }
                Date today = truncateTime(new Date());
                Date checkInTrunc = truncateTime(checkIn);
                if (checkInTrunc.before(today))
                {
                    System.out.println("❌ Check-in date cannot be in the past. Please enter today's date or later.");
                    continue;
                }
                break;
            }
            Date checkOut;
            while (true)
            {
                try
                {
                    checkOut = readDate("Enter Check-Out Date (MM/dd/yyyy): ");
                }
                catch (ParseException pe)
                {
                    System.out.println("Invalid date format. Please use MM/dd/yyyy.");
                    continue;
                }
                Date checkInTrunc = truncateTime(checkIn);
                Date checkOutTrunc = truncateTime(checkOut);
                if (!checkOutTrunc.after(checkInTrunc))
                {
                    System.out.println("❌ Check-out date must be after the check-in date.");
                    continue;
                }
                break;
            }
            Collection<IRoom> availableRooms = hotelResource.findARoom(checkIn, checkOut);
            Date usedCheckIn = checkIn;
            Date usedCheckOut = checkOut;
            if (availableRooms == null || availableRooms.isEmpty())
            {
                System.out.println("No rooms available for these dates.");
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(checkIn);
                calendar.add(Calendar.DATE, 7);
                Date recommendedCheckIn = calendar.getTime();
                calendar.setTime(checkOut);
                calendar.add(Calendar.DATE, 7);
                Date recommendedCheckOut = calendar.getTime();
                Collection<IRoom> recommendedRooms =
                        hotelResource.findRecommendedRooms(recommendedCheckIn, recommendedCheckOut);
                if (recommendedRooms == null || recommendedRooms.isEmpty())
                {
                    System.out.println("No recommended rooms available 7 days after your selected dates.");
                    return;
                }
                else
                {
                    SimpleDateFormat formatter = new SimpleDateFormat(DATE_PATTERN);
                    System.out.println("We found recommended rooms for dates: "
                            + formatter.format(recommendedCheckIn) + " to "
                            + formatter.format(recommendedCheckOut));
                    for (IRoom room : recommendedRooms)
                    {
                        System.out.println(room);
                    }
                    availableRooms = recommendedRooms;
                    usedCheckIn = recommendedCheckIn;
                    usedCheckOut = recommendedCheckOut;
                }
            }
            else
            {
                System.out.println("Available rooms:");
                for (IRoom room : availableRooms) {
                    System.out.println(room);
                }
            }
            System.out.print("Would you like to book a room? (y/n): ");
            String book = scanner.nextLine();
            if (!book.equalsIgnoreCase("y"))
            {
                return;
            }
            System.out.print("Enter your email (you must have an account): ");
            String email = scanner.nextLine();
            if (hotelResource.getCustomer(email) == null)
            {
                System.out.println("No account found with that email. Please create an account first.");
                return;
            }
            System.out.print("Enter room number to book: ");
            String roomNumber = scanner.nextLine();
            IRoom room = hotelResource.getRoom(roomNumber);
            if (room == null)
            {
                System.out.println("Room number not found.");
                return;
            }
            Reservation reservation = hotelResource.bookARoom(email, room, usedCheckIn, usedCheckOut);
            System.out.println("Reservation created successfully:");
            System.out.println(reservation);
        }
        catch (Exception e)
        {
            System.out.println("Error while reserving a room: " + e.getMessage());
        }
    }
    private static Date readDate(String prompt) throws ParseException
    {
        System.out.print(prompt);
        String dateString = scanner.nextLine();
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);
        dateFormat.setLenient(false);
        return dateFormat.parse(dateString);
    }
    private static Date truncateTime(Date date)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
}
