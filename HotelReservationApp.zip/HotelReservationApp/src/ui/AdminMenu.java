package ui;
import api.AdminResource;
import model.IRoom;
import model.Room;
import model.RoomType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;
public class AdminMenu
{
    private static final AdminResource adminResource = AdminResource.getInstance();
    private static final Scanner scanner = new Scanner(System.in);
    public static void showAdminMenu()
    {
        String userInput;
        do
        {
            printAdminMenu();
            userInput = scanner.nextLine();
            switch (userInput)
            {
                case "1":
                    seeAllCustomers();
                    break;
                case "2":
                    seeAllRooms();
                    break;
                case "3":
                    seeAllReservations();
                    break;
                case "4":
                    addRoom();
                    break;
                case "5":
                    return;
                default:
                    System.out.println("Please select a valid option (1–5).");
            }
        }
        while(true);
    }
    private static void printAdminMenu()
    {
        System.out.println("\nAdmin Menu");
        System.out.println("--------------------------------------------");
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations");
        System.out.println("4. Add a Room");
        System.out.println("5. Back to Main Menu");
        System.out.println("--------------------------------------------");
        System.out.print("Please select a number for the menu option: ");
    }
    private static void seeAllCustomers()
    {
        Collection<model.Customer> customers = adminResource.getAllCustomers();
        if (customers.isEmpty())
        {
            System.out.println("No customers found.");
        } else
        {
            for (model.Customer customer : customers)
            {
                System.out.println(customer);
            }
        }
    }
    private static void seeAllRooms()
    {
        Collection<IRoom> rooms = adminResource.getAllRooms();
        if (rooms.isEmpty())
        {
            System.out.println("No rooms available.");
        } else
        {
            for (IRoom room : rooms)
            {
                System.out.println(room);
            }
        }
    }
    private static void seeAllReservations()
    {
        adminResource.displayAllReservations();
    }
    private static void addRoom() {
        List<IRoom> roomsToAdd = new ArrayList<>();
        String continueAdding;
        do {
            String roomNumber;
            while (true) {
                System.out.print("Enter room number: ");
                roomNumber = scanner.nextLine().trim();

                if (roomNumber.isEmpty() || roomNumber.equalsIgnoreCase("null"))
                {
                    System.out.println("❌ Room number cannot be empty.");
                    continue;
                }
                if (!roomNumber.matches("\\d+")) {
                    System.out.println("❌ Room number must be a positive whole number (e.g., 101).");
                    continue;
                }
                int num = Integer.parseInt(roomNumber);
                if (num <= 0) {
                    System.out.println("❌ Room number must be greater than zero.");
                    continue;
                }
                final String finalRoomNumber = roomNumber;
                boolean existsInSaved = adminResource.getAllRooms()
                        .stream()
                        .anyMatch(r -> r.getRoomNumber().equals(finalRoomNumber));
                boolean existsInPending = roomsToAdd
                        .stream()
                        .anyMatch(r -> r.getRoomNumber().equals(finalRoomNumber));
                if (existsInSaved || existsInPending)
                {
                    System.out.println("Room already exists!");
                    roomNumber = finalRoomNumber;
                    break;
                }
                roomNumber = finalRoomNumber;
                break;
            }
            final String finalRoomNumberCheck = roomNumber;
            boolean existsAlready =
                    adminResource.getAllRooms().stream()
                            .anyMatch(r -> r.getRoomNumber().equals(finalRoomNumberCheck))
                            ||
                            roomsToAdd.stream()
                                    .anyMatch(r -> r.getRoomNumber().equals(finalRoomNumberCheck));

            if (existsAlready) {
                System.out.print("Would you like to add another room? (y/n): ");
                continueAdding = scanner.nextLine().trim();
                continue;
            }

            double price;
            while (true) {
                System.out.print("Enter room price: ");
                String priceInput = scanner.nextLine().trim();
                if (priceInput.isEmpty() || priceInput.equalsIgnoreCase("null")) {
                    System.out.println("❌ Price cannot be empty.");
                    continue;
                }
                try
                {
                    price = Double.parseDouble(priceInput);
                    if (price < 0)
                    {
                        System.out.println("❌ Price cannot be negative.");
                        continue;
                    }
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("❌ Invalid number format. Please enter a number like 100 or 99.99.");
                }
            }
            RoomType roomType;
            while (true)
            {
                System.out.print("Enter room type (1 for SINGLE, 2 for DOUBLE): ");
                String typeInput = scanner.nextLine().trim();
                if ("1".equals(typeInput))
                {
                    roomType = RoomType.SINGLE;
                    break;
                }
                else if ("2".equals(typeInput))
                {
                    roomType = RoomType.DOUBLE;
                    break;
                }
                else
                {
                    System.out.println("❌ Invalid room type. Please enter 1 or 2.");
                }
            }
            Room room = new Room(roomNumber, price, roomType);
            roomsToAdd.add(room);
            System.out.println("Room " + roomNumber + " added to pending list.");
            System.out.print("Would you like to add another room? (y/n): ");
            continueAdding = scanner.nextLine().trim();
        }
        while (continueAdding.equalsIgnoreCase("y"));

        if (!roomsToAdd.isEmpty())
        {
            adminResource.addRoom(roomsToAdd);
            System.out.println("Rooms added successfully!");
        }
        else
        {
            System.out.println("No rooms were added.");
        }
    }
}
