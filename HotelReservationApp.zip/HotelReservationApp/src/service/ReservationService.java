package service;
import model.*;
import java.util.*;
public class ReservationService
{
    private static ReservationService INSTANCE;
    private final Map<String, IRoom> rooms = new HashMap<>();
    private final Set<Reservation> reservations = new HashSet<>();
    private ReservationService()
    {

    }
    public static ReservationService getInstance()
    {
        if (INSTANCE == null)
        {
            INSTANCE = new ReservationService();
        }
        return INSTANCE;
    }
    public void addRoom(IRoom room) {
        String roomId = room.getRoomNumber();
        if (roomId == null || roomId.trim().isEmpty())
        {
            System.out.println("❌ Cannot add room with empty room number.");
            return;
        }
        if (rooms.containsKey(roomId))
        {
            System.out.println("❌ Room '" + roomId + "' already exists. Skipping add.");
            return;
        }
        rooms.put(roomId, room);
    }

    public IRoom getARoom(String roomNumber)
    {
        return rooms.get(roomNumber);
    }
    public Collection<IRoom> getAllRooms()
    {
        return rooms.values();
    }
    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate)
    {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }
    public Collection<Reservation> getCustomersReservation(Customer customer)
    {
        Collection<Reservation> results = new ArrayList<>();
        for (Reservation reservation : reservations)
        {
            if (reservation.getCustomer().equals(customer))
            {
                results.add(reservation);
            }
        }
        return results;
    }
    public void printAllReservation()
    {
        if (reservations.isEmpty())
        {
            System.out.println("No reservations found.");
        } else
        {
            for (Reservation reservation : reservations)
            {
                System.out.println(reservation);
            }
        }
    }
    public Collection<IRoom> findRooms(Date checkIn, Date checkOut)
    {
        Collection<IRoom> availableRooms = new ArrayList<>(rooms.values());
        for (Reservation reservation : reservations)
        {
            if (datesOverlap(checkIn, checkOut,
                    reservation.getCheckInDate(), reservation.getCheckOutDate()))
            {

                availableRooms.remove(reservation.getRoom());
            }
        }
        return availableRooms;
    }
    private boolean datesOverlap(Date checkIn, Date checkOut, Date reservedCheckIn, Date reservedCheckOut)
    {
        return checkIn.before(reservedCheckOut) && checkOut.after(reservedCheckIn);
    }
    public Collection<IRoom> findRecommendedRooms(Date checkIn, Date checkOut)
    {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(checkIn);
        calendar.add(Calendar.DATE, 7);
        Date newCheckIn = calendar.getTime();
        calendar.setTime(checkOut);
        calendar.add(Calendar.DATE, 7);
        Date newCheckOut = calendar.getTime();
        return findRooms(newCheckIn, newCheckOut);
    }
}
