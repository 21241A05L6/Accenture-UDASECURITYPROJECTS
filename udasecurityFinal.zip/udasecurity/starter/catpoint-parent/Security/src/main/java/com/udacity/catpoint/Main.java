package com.udacity.catpoint;

import com.udacity.catpoint.application.CatpointGui;

public class Main {
    public static void main(String[] args) {
        new CatpointGui();   // Launch GUI
    }
}
