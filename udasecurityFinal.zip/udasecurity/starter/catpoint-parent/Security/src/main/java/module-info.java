module com.udacity.catpoint.security {
    requires java.desktop;
    requires java.prefs;
    requires miglayout.swing;
    requires com.google.gson;
    requires com.google.common;
    requires com.udacity.catpoint.image;

    opens com.udacity.catpoint.data to com.google.gson;
}
