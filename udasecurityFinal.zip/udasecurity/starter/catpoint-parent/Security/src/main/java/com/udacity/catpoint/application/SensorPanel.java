package com.udacity.catpoint.application;

import com.udacity.catpoint.data.AlarmStatus;
import com.udacity.catpoint.data.Sensor;
import com.udacity.catpoint.data.SensorType;
import com.udacity.catpoint.service.SecurityService;
import com.udacity.catpoint.service.StyleService;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;

public class SensorPanel extends JPanel implements StatusListener {

    private final SecurityService securityService;

    private JLabel panelLabel = new JLabel("Sensor Management");
    private JLabel newSensorName = new JLabel("Name:");
    private JLabel newSensorType = new JLabel("Sensor Type:");
    private JTextField newSensorNameField = new JTextField();
    private JComboBox newSensorTypeDropdown = new JComboBox(SensorType.values());
    private JButton addNewSensorButton = new JButton("Add New Sensor");

    private JPanel sensorListPanel;
    private JPanel newSensorPanel;

    public SensorPanel(SecurityService securityService) {
        super();
        this.securityService = securityService;
        setLayout(new MigLayout());

        panelLabel.setFont(StyleService.HEADING_FONT);

        addNewSensorButton.addActionListener(e ->
                addSensor(new Sensor(
                        newSensorNameField.getText(),
                        SensorType.valueOf(
                                newSensorTypeDropdown
                                        .getSelectedItem()
                                        .toString()))));

        newSensorPanel = buildAddSensorPanel();
        sensorListPanel = new JPanel(new MigLayout());

        updateSensorList(sensorListPanel);

        add(panelLabel, "wrap");
        add(newSensorPanel, "span");
        add(sensorListPanel, "span");

        securityService.addStatusListener(this);
    }

    private JPanel buildAddSensorPanel() {
        JPanel p = new JPanel(new MigLayout());
        p.add(newSensorName);
        p.add(newSensorNameField, "width 50:100:200");
        p.add(newSensorType);
        p.add(newSensorTypeDropdown, "wrap");
        p.add(addNewSensorButton, "span 3");
        return p;
    }

    private void updateSensorList(JPanel p) {
        p.removeAll();

        securityService.getSensors()
                .stream()
                .sorted()
                .forEach(s -> {
                    JLabel label = new JLabel(
                            String.format(
                                    "%s(%s): %s",
                                    s.getName(),
                                    s.getSensorType(),
                                    (s.getActive() ? "Active" : "Inactive")));

                    JButton toggle = new JButton(
                            (s.getActive() ? "Deactivate" : "Activate"));

                    JButton remove = new JButton("Remove Sensor");

                    toggle.addActionListener(e ->
                            setSensorActivity(s, !s.getActive()));

                    remove.addActionListener(e ->
                            removeSensor(s));

                    p.add(label, "width 300:300:300");
                    p.add(toggle, "width 100:100:100");
                    p.add(remove, "wrap");
                });

        repaint();
        revalidate();
    }

    private void setSensorActivity(Sensor sensor, Boolean active) {
        securityService.changeSensorActivationStatus(sensor, active);
        updateSensorList(sensorListPanel);
    }

    private void addSensor(Sensor sensor) {
        if (securityService.getSensors().size() < 4) {
            securityService.addSensor(sensor);
            updateSensorList(sensorListPanel);
        } else {
            JOptionPane.showMessageDialog(null,
                    "To add more than 4 sensors, please subscribe to Premium!");
        }
    }

    private void removeSensor(Sensor sensor) {
        securityService.removeSensor(sensor);
        updateSensorList(sensorListPanel);
    }


    @Override
    public void notify(AlarmStatus status) {}

    @Override
    public void catDetected(boolean cat) {}

    @Override
    public void sensorStatusChanged() {
        updateSensorList(sensorListPanel);
    }
}
