package com.udacity.catpoint.service;

import com.udacity.catpoint.application.StatusListener;
import com.udacity.catpoint.data.*;
import com.udacity.catpoint.image.ImageService;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

public class SecurityService {

    private final ImageService imageService;
    private final SecurityRepository securityRepository;
    private final Set<StatusListener> statusListeners = new HashSet<>();

    private boolean catDetected = false;

    public SecurityService(SecurityRepository securityRepository, ImageService imageService) {
        this.securityRepository = securityRepository;
        this.imageService = imageService;
    }

    /* ---------------- ARMING ---------------- */
    public void setArmingStatus(ArmingStatus armingStatus) {

        if (armingStatus == ArmingStatus.DISARMED) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
            catDetected = false;
        } else {

            // Reset all sensors to inactive
            Set<Sensor> copy = new HashSet<>(getSensors());
            copy.forEach(sensor -> {
                sensor.setActive(false);
                securityRepository.updateSensor(sensor);
            });

            statusListeners.forEach(StatusListener::sensorStatusChanged);

            // If cat was detected earlier + user arms HOME → alarm
            if (armingStatus == ArmingStatus.ARMED_HOME && catDetected) {
                setAlarmStatus(AlarmStatus.ALARM);
            }
        }

        securityRepository.setArmingStatus(armingStatus);
    }


    /* ---------------- CAT LOGIC ---------------- */
    private void handleCat(boolean cat) {

        catDetected = cat;

        boolean armed =
                getArmingStatus() == ArmingStatus.ARMED_HOME ||
                        getArmingStatus() == ArmingStatus.ARMED_AWAY;

        boolean anyActive =
                getSensors().stream().anyMatch(Sensor::getActive);

        // Cat detected + system armed → ALWAYS alarm
        if (cat && armed) {
            setAlarmStatus(AlarmStatus.ALARM);
            statusListeners.forEach(l -> l.catDetected(true));
            return;
        }

        // No cat + NO active sensors → only clear IF PENDING (NOT when ALARM!)
        if (!cat && !anyActive && getAlarmStatus() == AlarmStatus.PENDING_ALARM) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
            statusListeners.forEach(l -> l.catDetected(false));
            return;
        }

        statusListeners.forEach(l -> l.catDetected(cat));
    }


    /* ---------------- LISTENERS ---------------- */
    public void addStatusListener(StatusListener statusListener) {
        statusListeners.add(statusListener);
    }

    public void removeStatusListener(StatusListener statusListener) {
        statusListeners.remove(statusListener);
    }

    public void setAlarmStatus(AlarmStatus status) {
        securityRepository.setAlarmStatus(status);
        statusListeners.forEach(l -> l.notify(status));
    }


    /* ---------------- SENSOR LOGIC ---------------- */

    private void handleSensorActivated() {

        if (getArmingStatus() == ArmingStatus.DISARMED) return;

        if (getAlarmStatus() == AlarmStatus.PENDING_ALARM) {
            setAlarmStatus(AlarmStatus.ALARM);
            return;
        }

        if (getAlarmStatus() == AlarmStatus.NO_ALARM) {
            setAlarmStatus(AlarmStatus.PENDING_ALARM);
        }
    }

    private void handleSensorDeactivated() {

        AlarmStatus status = getAlarmStatus();

        // Pending + all inactive → back to NO_ALARM
        if (status == AlarmStatus.PENDING_ALARM) {
            boolean stillActive = getSensors().stream().anyMatch(Sensor::getActive);

            if (!stillActive) {
                setAlarmStatus(AlarmStatus.NO_ALARM);
            }
        }
        // IMPORTANT: DO NOT DOWNGRADE if already ALARM
    }

    public void changeSensorActivationStatus(Sensor sensor, Boolean active) {

        boolean wasActive = sensor.getActive();

        // If alarm already ALARM → ignore sensor changes
        if (getAlarmStatus() == AlarmStatus.ALARM) return;

        // Reactivating while pending → ALARM
        if (sensor.getActive()
                && active
                && getAlarmStatus() == AlarmStatus.PENDING_ALARM) {
            setAlarmStatus(AlarmStatus.ALARM);
            return;
        }

        sensor.setActive(active);
        securityRepository.updateSensor(sensor);

        if (!wasActive && active) {
            handleSensorActivated();
        } else if (wasActive && !active) {
            handleSensorDeactivated();
        }
    }

    public void processImage(BufferedImage image) {
        boolean cat = imageService.imageContainsCat(image, 50.0f);
        handleCat(cat);
    }
    public AlarmStatus getAlarmStatus() {
        return securityRepository.getAlarmStatus();
    }

    public Set<Sensor> getSensors()
    {
        return securityRepository.getSensors();
    }

    public void addSensor(Sensor sensor)
    {
        securityRepository.addSensor(sensor);
    }

    public void removeSensor(Sensor sensor)
    {
        securityRepository.removeSensor(sensor);
    }
    public ArmingStatus getArmingStatus()
    {
        return securityRepository.getArmingStatus();
    }
}
