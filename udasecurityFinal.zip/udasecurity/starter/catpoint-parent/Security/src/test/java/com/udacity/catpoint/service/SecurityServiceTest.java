package com.udacity.catpoint.service;
import com.udacity.catpoint.application.StatusListener;
import com.udacity.catpoint.data.*;
import com.udacity.catpoint.image.ImageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
public class SecurityServiceTest
{
    private SecurityRepository repo;
    private ImageService imageService;
    private SecurityService service;
    private StatusListener listener;
    @BeforeEach
    void setup() {
        repo = mock(SecurityRepository.class);
        imageService = mock(ImageService.class);
        service = new SecurityService(repo, imageService);
        listener = mock(StatusListener.class);
        service.addStatusListener(listener);
    }
    private Sensor sensor()
    {
        return new Sensor("s", SensorType.DOOR);
    }
    @Test
    void firstActivation_noAlarm_setsPending()
    {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        Sensor s = sensor();
        s.setActive(false);
        service.changeSensorActivationStatus(s,true);
        verify(repo).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }
    @Test
    void activatingSensorWhenPending_setsAlarm()
    {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        Sensor s1 = sensor();
        s1.setActive(true);
        Sensor s2 = sensor();
        s2.setActive(false);
        when(repo.getSensors()).thenReturn(Set.of(s1, s2));
        service.changeSensorActivationStatus(s2,true);
        verify(repo).setAlarmStatus(AlarmStatus.ALARM);
    }
    @Test
    void reActivatingAlreadyActiveSensorWhilePendingForcesAlarm()
    {
        Sensor s1 = sensor();
        Sensor s2 = sensor();
        s1.setActive(true);
        s2.setActive(true);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        when(repo.getSensors()).thenReturn(Set.of(s1, s2));
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        service.changeSensorActivationStatus(s1, true);
        verify(repo).setAlarmStatus(AlarmStatus.ALARM);
    }
    @Test
    void alarmActive_noCat_scan_doesNotClearAlarmEvenIfSensorActive() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        Sensor s = sensor();
        s.setActive(true);
        when(repo.getSensors()).thenReturn(Set.of(s));
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        service.processImage(mock(BufferedImage.class));
        verify(repo, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    @Test
    void alarmActive_sensorChangesIgnored() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        Sensor s = sensor();
        s.setActive(true);
        service.changeSensorActivationStatus(s, false);
        verify(repo, never()).setAlarmStatus(any());
    }
    @Test
    void pending_toInactive_setsNoAlarm() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        Sensor s = sensor();
        s.setActive(true);
        service.changeSensorActivationStatus(s,false);
        verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    @Test
    void disarmed_ignoresSensorActivation() {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.DISARMED);
        Sensor s = sensor();
        s.setActive(false);
        service.changeSensorActivationStatus(s, true);
        verify(repo, never()).setAlarmStatus(any());
    }
    @Test
    void catDetectedWhileDisarmed_doesNotTriggerAlarm() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.DISARMED);
        service.processImage(mock(BufferedImage.class));
        verify(repo, never()).setAlarmStatus(AlarmStatus.ALARM);
        verify(listener).catDetected(true);
    }
    @Test
    void armingHome_withoutPreviousCat_doesNotTriggerAlarm() {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        service.setArmingStatus(ArmingStatus.ARMED_HOME);
        verify(repo, never()).setAlarmStatus(AlarmStatus.ALARM);
    }
    @Test
    void catDetectedWhileArmedHome_setsAlarm() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        service.processImage(mock(BufferedImage.class));
        verify(repo).setAlarmStatus(AlarmStatus.ALARM);
        verify(listener).catDetected(true);
    }
    @Test
    void noCat_butActiveSensors_doesNotSetNoAlarm() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        Sensor s = sensor();
        s.setActive(true);
        when(repo.getSensors()).thenReturn(Set.of(s));
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        service.processImage(mock(BufferedImage.class));
        verify(repo, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    @Test
    void noCat_noActiveSensors_doesNotClearIfAlarmActive() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        when(repo.getSensors()).thenReturn(Set.of());
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        service.processImage(mock(BufferedImage.class));
        verify(repo, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    @Test
    void noCat_noActiveSensors_setsNoAlarm() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        when(repo.getSensors()).thenReturn(Set.of());
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        service.processImage(mock(BufferedImage.class));
        verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
        verify(listener).catDetected(false);
    }
    @Test
    void catDetectedWhileArmedAway_setsAlarm() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_AWAY);
        service.processImage(mock(BufferedImage.class));
        verify(repo).setAlarmStatus(AlarmStatus.ALARM);
    }
    @Test
    void pendingAlarm_withOtherActiveSensors_doesNotClearAlarm() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        Sensor active = sensor();
        active.setActive(true);
        when(repo.getSensors()).thenReturn(Set.of(active));
        Sensor s = sensor();
        s.setActive(true);
        service.changeSensorActivationStatus(s,false);
        verify(repo, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    @Test
    void disarming_setsNoAlarm() {
        service.setArmingStatus(ArmingStatus.DISARMED);
        verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
        verify(repo).setArmingStatus(ArmingStatus.DISARMED);
    }
    @Test
    void arming_resetsSensorsInactive() {
        Sensor s1 = sensor(); s1.setActive(true);
        Sensor s2 = sensor(); s2.setActive(true);
        Set<Sensor> set = new HashSet<>();
        set.add(s1); set.add(s2);
        when(repo.getSensors()).thenReturn(set);
        service.setArmingStatus(ArmingStatus.ARMED_HOME);
        verify(repo,times(2)).updateSensor(any());
        assertFalse(s1.getActive());
        assertFalse(s2.getActive());
    }
    @Test
    void previouslyDetectedCat_thenArmedHome_triggersAlarm() {
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        service.processImage(mock(BufferedImage.class));
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        service.setArmingStatus(ArmingStatus.ARMED_HOME);
        verify(repo, atLeastOnce()).setAlarmStatus(AlarmStatus.ALARM);
    }
    @ParameterizedTest
    @EnumSource(AlarmStatus.class)
    void inactiveSensorDeactivation_doesNotChangeAlarm(AlarmStatus status) {
        when(repo.getAlarmStatus()).thenReturn(status);
        Sensor s = sensor();
        s.setActive(false);
        service.changeSensorActivationStatus(s,false);
        verify(repo,never()).setAlarmStatus(any());
    }
    @Test
    void removedListener_notCalled() {
        StatusListener extra = mock(StatusListener.class);
        service.addStatusListener(extra);
        service.removeStatusListener(extra);
        service.setAlarmStatus(AlarmStatus.ALARM);
        verify(extra, never()).notify(any());
    }
    @Test
    void addRemoveDelegates() {
        Sensor s = sensor();
        service.addSensor(s);
        verify(repo).addSensor(s);
        service.removeSensor(s);
        verify(repo).removeSensor(s);
    }
    @ParameterizedTest
    @EnumSource(AlarmStatus.class)
    void sensorDeactivated_variousAlarmStates_exercisesAllBranches(AlarmStatus status) {
        Sensor s = sensor();
        s.setActive(true);

        when(repo.getAlarmStatus()).thenReturn(status);
        when(repo.getSensors()).thenReturn(Set.of(s));

        service.changeSensorActivationStatus(s, false);

        if (status == AlarmStatus.PENDING_ALARM) {
            verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
        } else {
            verify(repo, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
        }
    }
    @Test
    void sensorAlreadyActive_activatedAgain_doesNothingUnlessPending() {
        Sensor s = sensor();
        s.setActive(true);

        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);

        service.changeSensorActivationStatus(s, true);

        verify(repo, never()).setAlarmStatus(any());
    }
    @Test
    void sensorActivatedWhileAlarmActive_doesNothing() {
        Sensor s = sensor();
        s.setActive(false);

        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);

        service.changeSensorActivationStatus(s, true);

        verify(repo, never()).setAlarmStatus(any());
    }
    @Test
    void sensorDeactivated_whenOtherSensorsActive_doesNotClearAlarm() {
        Sensor s1 = sensor();
        Sensor s2 = sensor();
        s1.setActive(true);
        s2.setActive(true);

        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        when(repo.getSensors()).thenReturn(Set.of(s1, s2));

        service.changeSensorActivationStatus(s1, false);

        verify(repo, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    @Test
    void secondSensorActivation_whenTwoSensorsActive_triggersPendingFirst() {
        Sensor s1 = sensor();
        Sensor s2 = sensor();
        s1.setActive(true);
        s2.setActive(false);

        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        when(repo.getSensors()).thenReturn(Set.of(s1, s2));

        service.changeSensorActivationStatus(s2, true);

        verify(repo).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }



}
